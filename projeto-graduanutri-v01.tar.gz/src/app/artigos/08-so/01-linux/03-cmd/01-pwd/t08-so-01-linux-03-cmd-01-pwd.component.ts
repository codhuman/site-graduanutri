import { Component } from '@angular/core';

@Component({
  selector: 'app-t08-so-01-linux-03-cmd-01-pwd',
  standalone: true,
  imports: [],
  templateUrl: './t08-so-01-linux-03-cmd-01-pwd.component.html',
  styleUrl: './t08-so-01-linux-03-cmd-01-pwd.component.scss'
})
export class T08So01Linux03Cmd01PwdComponent {}
