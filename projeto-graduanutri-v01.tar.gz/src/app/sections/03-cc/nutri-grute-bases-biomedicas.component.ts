import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-NutriGruteBasesBiomedicas',
  templateUrl: './nutri-grute-bases-biomedicas.component.html',
  styleUrls: ['./nutri-grute-bases-biomedicas.component.scss']
})
export class NutriGruteBasesBiomedicasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
