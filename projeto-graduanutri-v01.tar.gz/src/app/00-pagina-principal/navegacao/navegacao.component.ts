import { Component } from '@angular/core';

@Component({
  selector: 'app-navegacao',
  standalone: true,
  imports: [],
  templateUrl: './navegacao.component.html',
  styleUrl: './navegacao.component.scss'
})
export class NavegacaoComponent {

}
