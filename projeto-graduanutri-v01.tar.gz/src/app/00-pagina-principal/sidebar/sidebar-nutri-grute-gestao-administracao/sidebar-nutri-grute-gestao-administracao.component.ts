import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-gestao-administracao',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-gestao-administracao.component.html',
  styleUrl: './sidebar-nutri-grute-gestao-administracao.component.scss'
})
export class SidebarNutriGruteGestaoAdministracaoComponent {

}
