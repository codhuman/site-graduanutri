import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-estagios-tcc',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-estagios-tcc.component.html',
  styleUrl: './sidebar-nutri-grute-estagios-tcc.component.scss'
})
export class SidebarNutriGruteEstagiosTccComponent {

}
