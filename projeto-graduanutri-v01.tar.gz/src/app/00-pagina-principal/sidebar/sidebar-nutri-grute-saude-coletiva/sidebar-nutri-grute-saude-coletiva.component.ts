import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-saude-coletiva',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-saude-coletiva.component.html',
  styleUrl: './sidebar-nutri-grute-saude-coletiva.component.scss'
})
export class SidebarNutriGruteSaudeColetivaComponent {

}
