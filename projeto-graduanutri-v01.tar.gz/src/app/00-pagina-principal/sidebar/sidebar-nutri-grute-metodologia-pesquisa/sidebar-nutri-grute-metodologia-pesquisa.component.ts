import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-metodologia-pesquisa',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-metodologia-pesquisa.component.html',
  styleUrl: './sidebar-nutri-grute-metodologia-pesquisa.component.scss'
})
export class SidebarNutriGruteMetodologiaPesquisaComponent {

}
