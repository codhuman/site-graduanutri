import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-avaliacao-nutricional',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-avaliacao-nutricional.component.html',
  styleUrl: './sidebar-nutri-grute-avaliacao-nutricional.component.scss'
})
export class SidebarLinguagensComponent {

}
