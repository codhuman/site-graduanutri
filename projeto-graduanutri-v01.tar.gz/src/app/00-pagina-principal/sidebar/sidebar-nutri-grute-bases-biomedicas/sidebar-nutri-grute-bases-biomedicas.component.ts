import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-bases-biomedicas',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-bases-biomedicas.component.html',
  styleUrl: './sidebar-nutri-grute-bases-biomedicas.component.scss'
})
export class SidebarNutriGruteBasesBiomedicasComponent {

}
