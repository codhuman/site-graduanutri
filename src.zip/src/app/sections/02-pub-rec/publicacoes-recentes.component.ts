import { Component } from '@angular/core';

@Component({
  selector: 'app-publicacoes-recentes',
  standalone: true,
  templateUrl: './publicacoes-recentes.component.html',
  styleUrls: ['./publicacoes-recentes.component.scss']
})
export class PublicacoesRecentesComponent {
  constructor() { }

  ngOnInit(): void {
  }
}
