import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-nutricao-dietetica',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-nutricao-dietetica.component.html',
  styleUrl: './sidebar-nutri-grute-nutricao-dietetica.component.scss'
})
export class SidebarHardwareComponent {

}
