import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-alimentos-tecnologia',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-alimentos-tecnologia.component.html',
  styleUrl: './sidebar-nutri-grute-alimentos-tecnologia.component.scss'
})
export class SidebarNutriGruteAlimentosTecnologiaComponent {

}
