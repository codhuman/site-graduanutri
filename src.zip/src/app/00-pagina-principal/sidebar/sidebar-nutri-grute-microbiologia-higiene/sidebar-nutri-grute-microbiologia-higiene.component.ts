import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-microbiologia-higiene',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-microbiologia-higiene.component.html',
  styleUrl: './sidebar-nutri-grute-microbiologia-higiene.component.scss'
})
export class SidebarNutriGruteMicrobiologiaHigieneComponent {

}
