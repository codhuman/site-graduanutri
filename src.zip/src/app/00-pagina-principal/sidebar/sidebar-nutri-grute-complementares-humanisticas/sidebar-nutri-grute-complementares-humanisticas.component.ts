import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-nutri-grute-complementares-humanisticas',
  standalone: true,
  imports: [],
  templateUrl: './sidebar-nutri-grute-complementares-humanisticas.component.html',
  styleUrl: './sidebar-nutri-grute-complementares-humanisticas.component.scss'
})
export class SidebarNutriGruteComplementaresHumanisticasComponent {

}
